//
//  ListItemRow.swift
//  iOSTest
//
//  Created by Zaynab Alarab on 06/12/2023.
//

import UIKit

class ListItemRow: UIView {
  
  @IBOutlet private weak var containerView: UIView!
  @IBOutlet private weak var imageView: UIImageView!
  @IBOutlet private weak var detailName: UILabel!
  @IBOutlet private weak var detailValue: UILabel!
  
  var statusTextColor: UIColor?
  var statusBackgourndColor: UIColor?
  var statusCornerRadius: CGFloat?
  
  func setup(iconName: UIImageView, value: String) {}
}

