//
//  ViewController.swift
//  iOSTest
//
//  Created by Zaynab Alarab on 08/12/2023.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet var containerScrollerView: UIScrollView!
    @IBOutlet var containerStackView: UIStackView!
    @IBOutlet var sliderCollectionView: UICollectionView!
    @IBOutlet var imagesPageControl: UIPageControl!
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet var listTableView: UITableView!
    @IBOutlet var listTableViewHeight: NSLayoutConstraint!
    
    var imagesArray: [UIImage] = []
    var listItemsArray: [listItem] = []
    var searchingItemsArray: [listItem] = []
    var isSearching = false
    var imageIndex: Int = 0
    var searchBarInitialOffSet: CGFloat = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        setupImagesSlider()
        setupSearchBar()
        setupListView()
    }
    
    func getData() {
        imagesArray = DataSource().imagesArray
        listItemsArray = imageIndex == 0 ? DataSource().classicCardItems : DataSource().premiumCardItems
    }
    
    func setupImagesSlider() {
        sliderCollectionView.dataSource = self
        sliderCollectionView.delegate = self
        sliderCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "collection-cell")
        
        imagesPageControl.numberOfPages = imagesArray.count
        imagesPageControl.currentPage = 0
        imagesPageControl.currentPageIndicatorTintColor = UIColor(red: 0x7A/255.0, green: 0xEE/255.0, blue: 0x00/255.0, alpha: 1.0)
        imagesPageControl.pageIndicatorTintColor = UIColor(red: 0x00/255.0, green: 0x0E/255.0, blue: 0x3C/255.0, alpha: 1.0)
    }
    
    func setupSearchBar() {
        searchBar.delegate = self
        searchBar.placeholder = "Search"
        searchBarInitialOffSet = searchBar.frame.origin.y
    }
    
    func setupListView() {
        listTableView.dataSource = self
        listTableView.delegate = self
        listTableView.register(UITableViewCell.self, forCellReuseIdentifier: "table-cell")
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == containerScrollerView {
            searchBar.frame.origin.y = max(searchBarInitialOffSet, containerScrollerView.contentOffset.y)
        } else {
            let visibleRect = CGRect(origin: sliderCollectionView.contentOffset, size: sliderCollectionView.bounds.size)
            let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
            
            if let indexPath = sliderCollectionView.indexPathForItem(at: visiblePoint) {
                imagesPageControl.currentPage = indexPath.row
            }
        }
    }
}

// MARK: Collection View Setup

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagesArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection-cell", for: indexPath)
                
        imageIndex = indexPath.row
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }
        
        let imageView = UIImageView(frame: cell.contentView.bounds)
        imageView.contentMode = .scaleAspectFit
        imageView.image = imagesArray[indexPath.row]
        
        cell.contentView.addSubview(imageView)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let visibleIndexPath = collectionView.indexPathsForVisibleItems.first else {
            return
        }
        imageIndex = visibleIndexPath.row
        isSearching = false
        searchBar.text = nil
        getData()
        listTableView.reloadData()
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = sliderCollectionView.frame.size
        return CGSize(width: size.width, height: size.height)
    }
}

// MARK: Search Bar Setup

extension ViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            isSearching = false
        } else {
            searchingItemsArray = listItemsArray.filter { $0.description.range(of: searchText, options: .caseInsensitive) != nil }
            isSearching = true
        }

        listTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        searchBar.text = nil
        listTableView.reloadData()
    }
}

// MARK: Table View Setup

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearching ? searchingItemsArray.count : listItemsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "table-cell", for: indexPath)

        let listItem = isSearching ? searchingItemsArray[indexPath.row] : listItemsArray[indexPath.row]
        cell.textLabel?.text = listItem.description
        
        let imageName = listItem.iconName
        cell.imageView?.image = UIImage(named: imageName)
        
        cell.selectionStyle = .none
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        
        return cell
    }
}
