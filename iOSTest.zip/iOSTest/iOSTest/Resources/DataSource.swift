//
//  DataSource.swift
//  iOSTest
//
//  Created by Zaynab Alarab on 08/12/2023.
//

import UIKit

struct DataSource {
    
    // MARK: Images Data
    
    var imagesArray = [
        UIImage(named: "ila-classic-card")!,
        UIImage(named: "ila-premium-card")!
    ]

    // MARK: List Data
    
    var classicCardItems: [listItem] = [
        listItem(iconName: "minus-icon", description: "Manage your money the smart way"),
        listItem(iconName: "minus-icon", description: "24/7 banking"),
        listItem(iconName: "minus-icon", description: "Fund your account flexibly"),
        listItem(iconName: "minus-icon", description: "Get rewarded instantly"),
        listItem(iconName: "minus-icon", description: "Can be used for anything you want"),
        listItem(iconName: "minus-icon", description: "Security and peace"),
        listItem(iconName: "minus-icon", description: "Access your money seamlessly"),
        listItem(iconName: "minus-icon", description: "Travel with ease"),
        listItem(iconName: "minus-icon", description: "Send money simply"),
        listItem(iconName: "minus-icon", description: "Track your spending"),
        listItem(iconName: "minus-icon", description: "Fully secure for your peace of mind"),
        listItem(iconName: "minus-icon", description: "Check your balance"),
        listItem(iconName: "minus-icon", description: "Donating to charities"),
        listItem(iconName: "minus-icon", description: "Convenience"),
        listItem(iconName: "minus-icon", description: "Security"),
        listItem(iconName: "minus-icon", description: "No Incurred Debt or Interest"),
        listItem(iconName: "minus-icon", description: "Few or No Fees"),
        listItem(iconName: "minus-icon", description: "Holds You Accountable for All Spending"),
        listItem(iconName: "minus-icon", description: "Makes It Easier To Stick To Your Budget"),
        listItem(iconName: "minus-icon", description: "May Offer Perks or Rewards"),
        listItem(iconName: "minus-icon", description: "Credit Score Doesn’t Matter"),
        listItem(iconName: "minus-icon", description: "Can Be Used With Digital Wallets"),
        listItem(iconName: "minus-icon", description: "Auto-Pay Bills"),
        listItem(iconName: "minus-icon", description: "Shop Online"),
    ]
     
    var premiumCardItems: [listItem] = [
        listItem(iconName: "minus-icon", description: "Higher Interest Rates"),
        listItem(iconName: "minus-icon", description: "Up to 50% less on fees and charges"),
        listItem(iconName: "minus-icon", description: "Better foreign exchange rates"),
        listItem(iconName: "minus-icon", description: "Exclusive discounts and offers"),
        listItem(iconName: "minus-icon", description: "World Mastercard Benefits"),
        listItem(iconName: "minus-icon", description: "Higher transaction limits"),
        listItem(iconName: "minus-icon", description: "Second Bahraini Dinar Account"),
        listItem(iconName: "minus-icon", description: "Up to 10% cashback on Booking.com"),
        listItem(iconName: "minus-icon", description: "European Shopping Village Offers "),
        listItem(iconName: "minus-icon", description: "30% discount on shipping using MyUS"),
        listItem(iconName: "minus-icon", description: "10% off when you book your flight"),
        listItem(iconName: "minus-icon", description: "Access to Airport lounges"),
        listItem(iconName: "minus-icon", description: "Comprehensive Travel Insurance"),
        listItem(iconName: "minus-icon", description: "Gadget Insurance"),
        listItem(iconName: "minus-icon", description: "Online Shopping Protection"),
        listItem(iconName: "minus-icon", description: "Convenience"),
        listItem(iconName: "minus-icon", description: "Security"),
        listItem(iconName: "minus-icon", description: "No Incurred Debt or Interest"),
        listItem(iconName: "minus-icon", description: "Few or No Fees"),
        listItem(iconName: "minus-icon", description: "Holds You Accountable for All Spending"),
        listItem(iconName: "minus-icon", description: "Makes It Easier To Stick To Your Budget"),
        listItem(iconName: "minus-icon", description: "May Offer Perks or Rewards"),
        listItem(iconName: "minus-icon", description: "Credit Score Doesn’t Matter"),
        listItem(iconName: "minus-icon", description: "Can Be Used With Digital Wallets"),
        listItem(iconName: "minus-icon", description: "Auto-Pay Bills"),
    ]
}

struct listItem {
    var iconName: String
    var description: String
}
