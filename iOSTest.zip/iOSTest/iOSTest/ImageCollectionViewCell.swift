//
//  ImageCollectionViewCell.swift
//  iOSTest
//
//  Created by Zaynab Alarab on 06/12/2023.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
}
